<script setup>
import { ref } from 'vue'
</script>

<template>
<h1>QnA</h1>
</template>
