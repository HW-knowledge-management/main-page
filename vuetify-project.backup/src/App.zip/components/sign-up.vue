<script setup>
import { ref, defineEmits } from 'vue'
const emit = defineEmits(['changeComponent'])

const username = ref('')
const password = ref('')
const userData = ref(null)

function submitForm() {

    const userData = {
        username: username.value,
        password: password.value
    }

    const res = await fetch(
        `http://localhost:3001/User`
    )
  
    userData.value = await res.json()
    console.log(userData.value.userId)


//  emit('changeComponent');
}

</script>

<template>
<h1>sign-up</h1>
<form @submit.prevent="submitForm()">
    <label>id</label>
    <input id="username" type="text" v-model="username">

    <label>password</label>
    <input id="password" type="password" v-model="password">
    <input type="submit" value="확인"></input>
</form>
</template>
